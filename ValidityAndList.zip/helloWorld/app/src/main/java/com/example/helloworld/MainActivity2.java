package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView text =  (TextView)findViewById(R.id.textView2);
        SharedPreferences sp = getSharedPreferences("key", 0);
        String tValue = sp.getString("textvalue","");
        text.setText(tValue);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1);
        ListView list = (ListView)findViewById(R.id.listView);
        adapter.add("one");
        adapter.add("two");
        adapter.add("three");
        adapter.add("four");
        adapter.add("five");
        adapter.add("six");
        adapter.add("seven");
        adapter.add("eight");
        adapter.add("nine");
        adapter.add("ten");
        adapter.add("eleven");
        adapter.add("twelve");
        adapter.add("thirteen");
        adapter.add("fourteen");
        adapter.add("fifteen");
        list.setAdapter(adapter);


    }
}
